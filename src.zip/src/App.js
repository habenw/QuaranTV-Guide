import React from "react";
import "./App.css";
// import Header from "./components/Header";
// import Movie from "./components/Movie";
// import Search from "./components/Search";
import {  Router,Link} from '@reach/router';
import Wrapper from "./components/Wrapper";
import Main from "./components/Main";




function App() {

    
    return (
     <div className="App">
      <Wrapper/>
      <Main/>
      {/* <Link to={"/movies/"}>
          Find
        </Link>
        <Router>
        <Main path="/movies" />
        </Router> */}
    </div>
   );
};


export default App;